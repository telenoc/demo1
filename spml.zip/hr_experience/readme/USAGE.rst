To use this module, you need to:

**Manage employee's academic experiences:**

1. Go to menu *Human Resources -> Experiences -> Academic Experiences*

or you can:

1. Go to menu *Human Resources -> Human Resources -> Employees*
2. Open employee date
3. Goto *Academic Experiences* tab


**Manage employee's professional experiences:**

1. Go to menu *Human Resources -> Experiences -> Professional Experiences*

or you can:

1. Go to menu *Human Resources -> Human Resources -> Employees*
2. Open employee date
3. Goto *Professional Experiences* tab

**Manage employee's certification:**

1. Go to menu *Human Resources -> Experiences -> Certifications*

or you can:

1. Go to menu *Human Resources -> Human Resources -> Employees*
2. Open employee date
3. Goto *Certifications* tab
