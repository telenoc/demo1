from . import hr_curriculum
from . import hr_academic
from . import hr_certification
from . import hr_experience
from . import hr_employee
