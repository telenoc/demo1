Float discount for order & invoice lines

In addition to the percentage discount, you can now add its value directly. It's simple, fast and easy.