Company wide unique employee ID. Supports:

* Random ID Generation
* Sequence

This module supports sequence of employee ID which will be generated
automatically from the sequence predefined.

Nevertheless, if you need a difference ID in particular cases
you can pass a custom value for `identification_id`: if you do it
no automatic generation happens.