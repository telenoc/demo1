# See LICENSE file for full copyright and licensing details.

from . import hr_recruitment
from . import hr_recruitment_employee
from . import training
