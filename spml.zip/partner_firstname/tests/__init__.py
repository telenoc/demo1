from . import (
    test_create,
    test_defaults,
    test_delete,
    test_empty,
    test_name,
    test_onchange,
    test_user_onchange,
    test_order,
    test_copy,
)
