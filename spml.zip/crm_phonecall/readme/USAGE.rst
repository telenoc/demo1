To use this module, you need to:

#. Go to *Sales > Phone Calls > Logged Calls > Create*.
#. If your user has *Show Scheduled Calls Menu* permission, you will see
   scheduled calls menu too.
#. In any moment you can schedule another call, schedule a meeting or convert
   call contact to opportunity.
#. Calls can be categorized and you can manage categories in *Sales >
   Configuration > Leads & Opportunities > Phone Calls > Categories*.
#. Calls can be analyzed in *Sales > Reports > Phone Calls Analysis*.
